plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.fsdjamil2012.loader"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.fsdjamil2012.loader"
        minSdk = 23
        targetSdk = 28
        versionCode = 1
        versionName = "1.0"
    }
}
