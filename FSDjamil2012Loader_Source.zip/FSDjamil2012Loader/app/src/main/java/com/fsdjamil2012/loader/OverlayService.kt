package com.fsdjamil2012.loader

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var panel: LinearLayout? = null

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showPanel()
    }

    private fun showPanel() {
        if (panel != null) return

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(10))
            setBackgroundColor(Color.rgb(23, 25, 39))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val title = TextView(this).apply {
            text = "FSDjamil2012"
            textSize = 17f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.rgb(145, 163, 255))
        }
        val minimize = Button(this).apply {
            text = "−"
            minWidth = dp(42)
        }
        val close = Button(this).apply {
            text = "×"
            minWidth = dp(42)
        }

        header.addView(title, LinearLayout.LayoutParams(0, dp(48), 1f))
        header.addView(minimize)
        header.addView(close)
        root.addView(header)

        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        val subtitle = TextView(this).apply {
            text = "EvoWorld Loader • Android"
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, 0, 0, dp(8))
        }
        body.addView(subtitle)

        addToggle(body, "Зрение (ESP)")
        addToggle(body, "Опасность")
        addToggle(body, "Имена игроков")

        val info = TextView(this).apply {
            text = "Демонстрационный режим — функции игры не подключены"
            textSize = 11f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        }
        body.addView(info)
        root.addView(body)

        minimize.setOnClickListener {
            body.visibility = if (body.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            minimize.text = if (body.visibility == View.VISIBLE) "−" else "+"
        }
        close.setOnClickListener { stopSelf() }

        val windowParams = WindowManager.LayoutParams(
            dp(280),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12)
            y = dp(120)
        }

        header.setOnTouchListener(object : View.OnTouchListener {
            private var startX = 0
            private var startY = 0
            private var touchX = 0f
            private var touchY = 0f

            override fun onTouch(view: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = windowParams.x
                        startY = windowParams.y
                        touchX = event.rawX
                        touchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        windowParams.x = startX + (event.rawX - touchX).toInt()
                        windowParams.y = startY + (event.rawY - touchY).toInt()
                        try {
                            windowManager.updateViewLayout(root, windowParams)
                        } catch (_: Exception) { }
                        return true
                    }
                }
                return false
            }
        })

        try {
            windowManager.addView(root, windowParams)
            panel = root
        } catch (_: Exception) {
            Toast.makeText(this, "Не удалось открыть окно. Проверь разрешение.", Toast.LENGTH_LONG).show()
            stopSelf()
        }
    }

    private fun addToggle(parent: LinearLayout, label: String) {
        var enabled = false
        val button = Button(this).apply {
            text = "$label: ВЫКЛ"
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(48, 53, 76))
        }
        button.setOnClickListener {
            enabled = !enabled
            button.text = "$label: ${if (enabled) "ВКЛ" else "ВЫКЛ"}"
        }
        parent.addView(button, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(46)
        ))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (panel == null) showPanel()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        panel?.let {
            try { windowManager.removeView(it) } catch (_: Exception) { }
        }
        panel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
